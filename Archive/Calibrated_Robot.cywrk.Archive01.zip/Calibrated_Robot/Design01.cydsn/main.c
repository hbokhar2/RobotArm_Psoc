#include "project.h"
#include "math.h"

int previous_compare = 0;

//Link Lengths
float X_end = 5.0;
float Y_end = 9.0;

float a1 = 5.0;
float a2 = 6.2;
float a3 = 5.5;
float a4 = 7;

float Theta1 = 0;
float Theta2 = 0;
float r1 = 0.0;
float phi_1 = 0.0;
float phi_2 = 0.0;
float phi_3 = 0.0;

typedef enum{
    pwm_1 = 1,
    pwm_2 = 2,
}PWM_type;

int BaseMotor_Theta(float Angle){

    int compare;
    int min_comp = 1400; 
    int max_comp = 7200; 
    int min_angle = 0; 
    int max_angle = 180;
    
    compare = ((max_comp-min_comp)/(max_angle-min_angle)) * (Angle-min_angle) + min_comp;
    return compare;
}

int TopMotor_Theta(float Angle){

    int compare;
    int min_comp = 1400; 
    int max_comp = 7100; 
    int min_angle = -90; 
    int max_angle = 90;
    
    compare = ((max_comp-min_comp)/(max_angle-min_angle)) * (Angle-min_angle) + min_comp;
    return compare;
}

/*MoveMotor function takes two arguments:
    - Compare value that controls the pwm of the motor.
    - Which pwm since we have two pwms.

What is accomplished with these two arguments:
    - Smooths motor movement by slowly incrementing to desired compare value. Prevents motor from spinning out due to too much momentum.
    - Remembers previous compare value using the global variable, "previous_compare".*/

void MoveMotor(int compare, PWM_type pwm) {
    
    if (compare - previous_compare > 0) {
        for (int i = previous_compare; i <= compare; i += 20) {
            if (pwm == pwm_1) {
                PWM_WriteCompare1(i);
            } else {
                PWM_WriteCompare2(i);
            }
            CyDelay(4);
        }

    } 

    else if (compare - previous_compare < 0) {
        for (int i = previous_compare; i >= compare; i -= 20) {
            if (pwm == pwm_1) {
                PWM_WriteCompare1(i);
            } else {
                PWM_WriteCompare2(i);
            }
            CyDelay(4);  
        }
    }
    previous_compare = compare;
    CyDelay(1000);
}


int main(void){
    PWM_Start();
    CyGlobalIntEnable;

    r1 = sqrt((X_end*X_end)+(pow(Y_end,2)));
    phi_1 = atan(Y_end/X_end);
    phi_2 = acos(((a4*a4)-(a2*a2)-(r1*r1))/(-2*a2*r1));
    phi_3 = acos(((r1*r1)-(a2*a2)-(a4*a4))/(-2*a2*a4));
    
    if (X_end > 0){
        
        Theta1 = phi_1 - phi_2;
        Theta1 = (Theta1*180)/3.14159;

        Theta2 = 3.14159 - phi_3;
        Theta2 = (Theta2*180)/3.14159;
        
    }else{
        Theta1 = 3.14159 + phi_1 + phi_2;
        Theta1 = (Theta1*180)/3.14159;
        Theta2 = -3.14159 + phi_3;
        Theta2 = (Theta2*180)/3.14159;    
    }
    

    MoveMotor(BaseMotor_Theta(Theta1), pwm_1);
    MoveMotor(TopMotor_Theta(Theta2), pwm_2);
    
    while(1){
        
    }
}

